#include "display.hpp"
#include "drivers\plasma\ws2812.hpp"
#include "common/pimoroni_common.hpp"
#include "pico/stdlib.h"

using namespace pimoroni;
using namespace plasma;

// Set how many LEDs you have
const uint NUM_LEDS = 64;

// Unicorns Hats setup, int?

WS2812 led_strip[8] = {
    WS2812(NUM_LEDS, pio0, 0, 21, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB),
    WS2812(NUM_LEDS, pio0, 1, 20, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB),
    WS2812(NUM_LEDS, pio0, 2, 19, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB),
    WS2812(NUM_LEDS, pio0, 3, 18, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB),
    WS2812(NUM_LEDS, pio1, 0, 17, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB),
    WS2812(NUM_LEDS, pio1, 1, 16, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB),
    WS2812(NUM_LEDS, pio1, 2, 15, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB),
    WS2812(NUM_LEDS, pio1, 3, 14, WS2812::DEFAULT_SERIAL_FREQ, false, WS2812::COLOR_ORDER::GRB)
};



namespace display {
    uint8_t buffer[BUFFER_SIZE];
    PicoGraphics_PenRGB888 graphics(WIDTH, HEIGHT, &buffer);


    void init() {
        // Initialize the Unicorn Hats

        for (int i = 0; i < 8; i++) {
        led_strip[i].start(60);
        //led_strip[i].set_brightness(0.001); // not required
        led_strip[i].clear(); // Clear the strip
        led_strip[i].update(); // Update the strip to show the changes
    }

        info("rdy");
    }

    void info(std::string_view text) {
        graphics.set_pen(0, 0, 0);
        graphics.clear();
        graphics.set_pen(255, 255, 255);
        graphics.set_font("bitmap5");
        graphics.text(text, Point(0, 0), WIDTH, 1);
        update();
    }

    void update() {
        // display update
    }

    void play_note(uint8_t channel, uint16_t freq, uint8_t waveform, uint16_t a, uint16_t d, uint16_t s, uint16_t r, uint8_t phase) {
        // not supported on the Gigantic Unicorn
    }

    void play_audio(uint8_t *audio_buffer, size_t len) {
        // not supported on the Gigantic Unicorn
    } 
}